
package com.example.app1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//       just like the DOM, the elements are poking the view elements
//       TextView -- for text display(id - textName)
//       EditText -- to enter the text(id- enterText)
//       Button -- To add button(id- clickme)
        val greetingText = findViewById<TextView>(R.id.name)
        val inputField = findViewById<EditText>(R.id.enterText)
        val clickBtn = findViewById<Button>(R.id.clickme)
        val offerBtn = findViewById<Button>(R.id.btnOffers)

        var enteredName = ""
//      Setting an event listener, if clicked will execute the function encapsulated
        clickBtn.setOnClickListener{
//          Converting the entered value to string
            enteredName = inputField
                .text
                .toString()
                .replaceFirstChar { (it.uppercase()) }
            /*
            checking if the entered string is empty
            if yes, post a Toast msg on screen
            Toast.makeTest(contextType,Text,Length).show(to show the banner)
            */
            if (enteredName =="") {
                offerBtn.visibility = INVISIBLE
                greetingText.text = "Anonymous"
                Toast.makeText(
                this@MainActivity,
                "Please enter your Name!",
                Toast.LENGTH_SHORT)
                .show()
            }
            else {
//          creating the value as msg
                val message = "$enteredName!"
//            changing the value
                greetingText.text = message
//            clearing inputfield after msg is displayed
                inputField.text.clear()
                offerBtn.visibility = VISIBLE
            }
        }

        offerBtn.setOnClickListener {
            val intent = Intent(this,SecondActivity::class.java)
            intent.putExtra("USER", enteredName)
            startActivity(intent)
        }
    }
}